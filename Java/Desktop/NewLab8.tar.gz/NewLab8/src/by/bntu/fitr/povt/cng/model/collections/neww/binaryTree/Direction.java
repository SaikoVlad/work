package by.bntu.fitr.povt.cng.model.collections.neww.binaryTree;

public enum Direction {
    LEFT,RIGHT
}
