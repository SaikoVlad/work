package by.bntu.fitr.povt.cng.model.entity.container;

public enum ToyType {
    GARLAND, STUFFEDTOYS, LIGHTS
}
