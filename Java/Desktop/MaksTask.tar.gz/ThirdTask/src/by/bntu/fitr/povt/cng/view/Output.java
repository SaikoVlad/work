package by.bntu.fitr.povt.cng.view;

public class Output {
    public static void writeLine(Object outer){
        System.out.print(outer);
    }
    public static void writeRedLine(Object outer){
        System.err.println(outer);
    }
}
