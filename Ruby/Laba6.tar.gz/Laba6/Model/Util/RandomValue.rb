class RandomValue
  def RandomValue.get_random(max)
    return Random.rand max
  end
end