class MaxValue

  def MaxValue.solver(line)
    return line.split("").sort
  end

end