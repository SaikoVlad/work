class LCDandGCM

  def LCDandGCM.lcd(a,b)
    return b == 0? a: lcd(b,a % b)
  end

  def LCDandGCM.gcm(a,b)
    return (a/lcd(a,b) * b)
  end
  # public static int finderOfNod(int a, int b) {
  #   return b == 0 ? a : finderOfNod(b,a % b);
  # }
  #
  # public static int finderOfNok(int a, int b) {
  #   return (a/finderOfNod(a, b) * b);
  # }

end