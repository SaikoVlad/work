class HeadsAndTails

  public
  def HeadsAndTails.solver(max)

    tails = 0

    i = 0
    while i < max
      result = Random.rand 2
      if result == 0
        tails += 1
      end
      i += 1
    end
    return "Heads: #{max - tails}\nTails: #{tails}"

  end


  # public static int getHeadResult(int maxValue) {
  #   Random random = new Random();
  #   int heads = 0, tails = 0;
  #   int result = 0;
  #   for (int i = 0; i < maxValue; i++) {
  #       result = random.nextInt(2);
  #   if (result == 0) {
  #       tails++;
  #   }
  #   }
  #
  #   return tails;
  #   }
  #
  #   public static int getHead(int maxValue, int tails) {
  #     return maxValue - tails;
  #   }
end