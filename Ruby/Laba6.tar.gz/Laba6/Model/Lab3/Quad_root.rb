class QuadRoot

  def QuadRoot.finder(a, b, d, k)
    return (-b + k * Math.sqrt(d)) / (2 * a)
  end


end