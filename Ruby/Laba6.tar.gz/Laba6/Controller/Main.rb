require '../Model/Lab3/Dragon_info'
require '../Model/Lab3/Vowel_or_consonant'
require '../Model/Lab3/Quad_root'
require '../Model/Lab3/Mood'
require '../Model/Util/RandomValue'
require '../Model/Lab6/Dividers'
require '../Model/Lab6/HeadsAndTails'
require '../Model/Lab6/MaxValue'
require '../Model/Lab6/LCDandGCM'
require '../Model/Lab6/Palindrome'
require '../Model/Lab6/SimpleOrNo'
require '../Model/Lab6/Reverse'
require '../Model/Lab6/SumAndCount'
require '../Model/Lab6/PerfectOrNo'

class Main
  def Main.main

    # puts PerfectOrNo.solver 4
    # puts SumAndCount.get 1231
    # puts Reverse.do 12342
    # puts SimpleOrNo.check 7
    # puts Palindrome.get_palindrome 4
    # puts LCDandGCM.gcm 2,6
    # puts MaxValue.solver "592761"
    # puts HeadsAndTails.solver 99
    # puts Dividers.finder 81
    # puts Mood.solve RandomValue.get_random 5
    # puts QuadRoot.finder 1,32,4,2
    # puts VowelOrConsonant.solver "b"
    # puts DragonInfo.heads_and_eyes 432

  end
end

Main.main
